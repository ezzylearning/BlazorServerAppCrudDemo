﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorServerAppCrudDemo.Models;
using BlazorServerAppCrudDemo.Services;
using Microsoft.AspNetCore.Components;

namespace BlazorServerAppCrudDemo.Pages.Players
{
    public partial class Create
    {
        [Inject]
        protected IPlayersService PlayersService { get; set; }

        [Inject]
        protected IPositionsService PositionsService { get; set; }

        [Inject]
        public NavigationManager NavigationManager { get; set; }

        public Player Player { get; set; }
        private List<Position> Positions { get; set; }

        protected override async Task OnInitializedAsync()
        {
            Player = new Player();
            Positions = await PositionsService.GetPositionsList();
        }

        private async void SubmitPlayer()
        {
            await PlayersService.CreatePlayer(Player);

            NavigationManager.NavigateTo("/players");
        }
    }
}
