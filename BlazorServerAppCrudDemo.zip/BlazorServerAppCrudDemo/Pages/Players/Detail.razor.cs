﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorServerAppCrudDemo.Models;
using BlazorServerAppCrudDemo.Services;
using Microsoft.AspNetCore.Components;

namespace BlazorServerAppCrudDemo.Pages.Players
{
    public partial class Detail
    {
        [Inject]
        protected IPlayersService PlayersService { get; set; }
        
        [Parameter]
        public int Id { get; set; }

        public Player Player { get; set; }
        
        protected override async Task OnInitializedAsync()
        {
            Player = await PlayersService.GetPlayerById(Id);
        }
    }
}
