﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorServerAppCrudDemo.Models;
using BlazorServerAppCrudDemo.Services;
using Microsoft.AspNetCore.Components;

namespace BlazorServerAppCrudDemo.Pages.Players
{
    public partial class Edit
    {
        [Inject]
        protected IPlayersService PlayersService { get; set; }

        [Inject]
        protected IPositionsService PositionsService { get; set; }

        [Inject]
        public NavigationManager NavigationManager { get; set; }

        [Parameter]
        public int Id { get; set; }

        public Player Player { get; set; }
        private List<Position> Positions { get; set; }

        protected override async Task OnInitializedAsync()
        {
            Player = await PlayersService.GetPlayerById(Id);
            Positions = await PositionsService.GetPositionsList();
        }

        private async void SubmitPlayer()
        {
            await PlayersService.UpdatePlayer(Player);

            NavigationManager.NavigateTo("/players");
        }
    }
}
